"""SafeInstall demonstration programs."""
