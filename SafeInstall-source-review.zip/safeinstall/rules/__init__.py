"""Finding rules engine."""
