"""SafeInstall package."""
