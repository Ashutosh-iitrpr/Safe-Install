"""Artifact parsers."""
