"""Network gateway helpers."""
